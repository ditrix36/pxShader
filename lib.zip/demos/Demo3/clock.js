var c = canvas2d(600, 600,true,true);
background(COLORS.GRAY);
translate(WIDTH / 2, HEIGHT / 2);
function dr() {
    clear();
    date = new Date();
    var m = date.getMinutes(), s = date.getSeconds(), h = date.getHours() % 12,
            sec = arc({x: 0, y: 0, r: WIDTH / 3, stroke: {color: COLORS.GREEN, width: 5}, deg: 2 * PI * (s / 60)}),
            min = arc({x: 0, y: 0, r: WIDTH / 3 - 10, stroke: {color: COLORS.YELLOW, width: 5}, deg: 2 * PI * (m / 60)}),
            hr = arc({x: 0, y: 0, r: WIDTH / 3 - 20, stroke: {color: COLORS.RED, width: 5}, deg: 2 * PI * (h / 12)});
    save();
    rotate(-PI / 2);
    draw([sec, min, hr]);
    restore();
    
    save();
    rotate(PI*((s*2 / 60)-1));
    ls = line({from: [0, 0], to: [0, HEIGHT / 3.5], color: COLORS.GREEN});
    ls.draw();
    restore();
    
    save();
    rotate(PI*((m*2 / 60)-1));
    lm = line({from: [0, 0], to: [0, HEIGHT / 4], color: COLORS.YELLOW});
    lm.draw();
    restore();
    
    save();
    rotate(PI*((h*2 / 12)-1))
    lh = line({from: [0, 0], to: [0, HEIGHT / 8], color: COLORS.RED});
    lh.draw();
    restore();
    
    text({x: 0, y: 0, txt: (`${h}:${m}:${s}`), align: "center"}).draw();
    sec.deg = 2 * PI * (s / 60);
    min.deg = 2 * PI * (m / 60)
}
update(dr);