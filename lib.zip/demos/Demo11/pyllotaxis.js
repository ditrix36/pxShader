canvas2d(600, 600);
background(139);
var c = 4, n = 0, m = 5, ang = 137.8;
var color = [0, 50, 100]
function phyllotaxis() {
    var a = n * ang;
    var r = c * sqrt(n);
    x = r * cos(a) + WIDTH / 2;
    y = r * sin(a) + HEIGHT / 2;
    arc({x: x, y: y, r: 4, color: `rgb(${color[0]},${color[1]},${color[2]}`});
    n++;
    color[0] += 5;
    color[1] += m;
    color[2] += m;
    if (color[0] >= 255) {
        color[0] = rand(0, 5) * 5;

    }
    if (color[1] >= 255) {
        color[1] = rand(7, 12) * 5;
    }
    if (color[2] >= 255) {
        color[2] = rand(13, 20) * 5;
    }

}
var input = document.createElement("input");
input.value = ang;
input.onkeyup = function () {
    if (Number(this.value) !== NaN) {
        eraseShape();
        ang = Number(this.value);
        n = 0;
    }
}
document.body.appendChild(input);
animate(phyllotaxis, 30);