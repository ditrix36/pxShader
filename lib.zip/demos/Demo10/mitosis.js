canvas2d(400, 400);
background(COLORS.YELLOWGREEN);
transparency(0.8);
particles = [];
particle = arc({x: WIDTH / 2, y: HEIGHT / 2, r: 24, i: 200});
particles.push(particle);
function dir() {
    clear();
    particles.forEach((p, i) => {
        dx = rand(1, 2) === 1 ? 1 : -1;
        dy = rand(1, 2) === 1 ? 1 : -1;
        p.x += dx;
        p.y += dy;
        p.draw();
        if (p.i < 0) {
            p.i = null;
        } else {
            p.i--;
        }
        if (particles.length > 1) {
            for (m = 0; m < particles.length; m++) {
                pa = particles[m];
                if (intersect(pa,p)) {
                    if (p.i == null && pa.i == null) {
                        var f = arc({x: p.x, y: pa.y, r: (p.r + pa.r)/1.6, i: 200});
                        particles.push(f);
                        eraseShape(p);
                        eraseShape(pa);
                        particles.splice(m, 1);
                        particles.splice(i, 1);
                        return;
                    }
                }
            }
        }
        if (intersect([MP_X, MP_Y]) && CLICK) {
            dis = rand(-p.r * 4, p.r * 4);
            particles.push(arc({x: p.x + dis, y: p.y, r: p.r * 0.8, i: 200}));
            dis = rand(-p.r * 2, p.r * 2);
            particles.push(arc({x: p.x + dis, y: p.y, r: p.r * 0.8, i: 200}));
            particles.splice(i, 1);
            return;
        }
    })
}
update(dir, 20);