document.body.innerHTML = '<body>' +
        '<div id ="options">' +
        '<form>' +
        '<label>Max Distance:<input type="range" id="max_d" min="20" max="190" class="param"></label>' +
        '<label>Min Branch Width:<input type="range" id="min_width" min="1" max="20" class="param"></label>' +
        '<label>Max Branch Width:<input type="range" id="max_width" min="5" max="100" class="param"></label>' +
        '<label>Reduction Branch Rate:<input type="range" id="redux_rate" min="2" max="10" class="param"></label>' +
        '</form>' +
        '</div>' +
        '</script>' +
        '<style>' +
        '#canvas{' +
        'position:absolute;' +
        'top:0;' +
        'left:0;' +
        'width:50%;' +
        'height:70%;' +
        '}' +
        '#options{' +
        'font-family: Arial,sans-serif;' +
        'position:absolute;' +
        'top:0%;' +
        'left:50%;' +
        'width:50%;' +
        'height:70%;' +
        'text-align: center;' +
        '}' +
        '#options label+label{' +
        'display:block;' +
        'margin:50px auto;' +
        '}' +
        '</style>';
for (i = 0; i < document.getElementsByClassName("param").length; i++) {
    var el = document.getElementsByClassName("param")[i];
    el.addEventListener("change", config);
}
function config() {
    var val = this.value,
            attr = this.id;
    if (attr === "min_width") {
        val /= 10;
    }
    window[attr] = val;
    tree = new Tree();
}
var c = canvas2d(1074, 450),
        max_d = 170,
        min_d = 10,
        min_width = 1,
        max_width = 25,
        redux_rate = 6;
var root = new Branch({x: WIDTH / 2, y: HEIGHT}, {x: 0, y: -1}, null);
c.id = "canvas";
background(COLORS.GRAY);
function Branch(pos, dir, parent) {
    this.pos = pos;
    this.parent = parent;
    this.dir = dir;
    this.count = 0;
    this.len = 1.2;
    this.origDir = {x: this.dir.x, y: this.dir.y};
    if (this.parent) {
        this.width = dist(this.pos, root.pos);
        this.width /= WIDTH;
        this.width = pow((1 - this.width), (redux_rate)) * max_width;
        this.form = line({from: [this.pos.x, this.pos.y], to: [this.parent.x, this.parent.y], w: this.width});
    }
    this.reset = function () {
        this.dir = {x: this.origDir.x, y: this.origDir.y};
        this.count = 0;
    }
    this.next = function () {
        var npos = {x: this.pos.x + this.dir.x, y: this.pos.y + this.dir.y},
                cdir = {x: this.dir.x * this.len, y: this.dir.y * this.len},
                nextB = new Branch(npos, cdir, this.pos);
        return nextB;
    }
    this.draw = function () {
        if (this.parent) {
            this.form.draw();
        }
    }
}
function Tree() {
    this.leaves = [];
    this.branches = [];
    var root = new Branch({x: WIDTH / 2, y: HEIGHT}, {x: 0, y: -1}, null);
    this.branches.push(root);
    var current = root;
    var found = false;
    for (var i = 0; i < 500; i++) {
        this.leaves.push(arc({x: rand(0, WIDTH), y: rand(0, HEIGHT * 0.6), r: 2, color: COLORS.YELLOW}));
    }
    this.show = function () {
        for (i = 0; i < this.leaves.length; i++) {
            this.leaves[i].draw();
        }
        for (i = 0; i < this.branches.length; i++) {
            this.branches[i].draw();
        }
    }
    this.grow = function () {
        for (i = this.leaves.length - 1; i >= 0; i--) {
            var closestB = null,
                    record = max_d * 2;
            for (j = this.branches.length - 1; j >= 0; j--) {
                d = dist(this.branches[j].pos, this.leaves[i]);
                if (d < min_d) {
                    eraseShape(this.leaves[i]);
                    this.leaves.splice(i, 1);
                    closestB = null;
                    break;
                } else if (d < record) {
                    closestB = this.branches[j];
                    record = d;
                }
            }
            if (closestB !== null) {
                if (closestB.width > min_width) {
                    var ndir = new Object({x: (this.leaves[i].x - closestB.pos.x), y: (this.leaves[i].y - closestB.pos.y)});
                    var h = dist(ndir); //normalising
                    ndir.x /= h;
                    ndir.y /= h;
                    closestB.dir.x += ndir.x;
                    closestB.dir.y += ndir.y;
                    closestB.count++;
                }
            }
        }
        for (i = this.branches.length - 1; i >= 0; i--) {
            if (this.branches[i].count > 0) {
                this.branches[i].dir.x /= this.branches[i].count;
                this.branches[i].dir.y /= this.branches[i].count;
                this.branches.push(this.branches[i].next());
            }
            this.branches[i].reset();
        }
    }
    while (!found) {
        for (var i = 0; i < this.leaves.length; i++) {
            var d = sqrt(pow((current.pos.x - this.leaves[i].x), 2) + pow((current.pos.y - this.leaves[i].y), 2));
            if (d < max_d) {
//console.log(current,d);
                found = true;
                break;
            }
        }
        if (!found) {
            var branch = current.next();
            current = branch;
            this.branches.push(current);
        }
    }


}
var tree = new Tree();
update(function () {
    clear();
    tree.show();
    tree.grow();
})