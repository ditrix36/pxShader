var can = canvas2d(1500, 700);
var pix = getPixels();
for (x = 0; x < can.width; x++) {
    for (y = 0; y < can.height; y++) {
        var i = 0, a = (x / can.width) * 5 - 2.5, b = (y / can.height) * 5 - 2.5;
        while (i < 100) {
            var aa = (a * a - b * b) + a;
            var bb = 2 * a * b + b;
            a = aa;
            b = bb;
            if ((Math.abs(aa + bb)) > 25) {
                break;
            }
            i++;
        }
        if (i === 100) {
            color = 0;
        } else {
            color = (i / 100) * 255;
        }
        var index = (y * can.width + x) * 4;
        pix[index] = color;
        pix[index + 1] = color;
        pix[index + 2] = color;
        pix[index + 3] = 250;
    }
    setPixels();
}