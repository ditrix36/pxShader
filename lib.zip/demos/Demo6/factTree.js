canvas2d(1000, 600);
        background(COLORS.GRAY);
        var max_dist = 60,
                min_dist = 10;
        function tree() {
            this.leafs = [],
                    this.branches = [];
            for (i = 0; i < 500; i++) {
                this.leafs[i] = arc({x: rand(0, WIDTH), y: rand(0, HEIGHT - 300), r: 2});
            }
            var root = line({from: [WIDTH / 2, HEIGHT], to: [WIDTH / 2, HEIGHT - 1], pos: {x: WIDTH / 2, y: HEIGHT - 1}, dirc: {x: 0, y: -1}, dir: {x: 0, y: -1}, count: 0});
            this.branches.push(root);
                function nextBranch(branch) {
                    var b = line({pos: {x: (branch.to[0] + branch.dir.x), y: (branch.to[1] + branch.dir.y)}, dirc: {x: branch.dir.x, y: branch.dir.y}, from: [branch.to[0],branch.to[1]], to: [branch.to[0] + branch.dir.x, branch.to[1] + branch.dir.y], dir: ({x: branch.dir.x, y: branch.dir.y}), count: 0});
                    return b;
                }
                var found = false, current = root;
                while (!found) {
                    for (i = this.leafs.length - 1; i >= 0; i--) {
                        if (dist(current.pos, this.leafs[i]) < max_dist) {
                            found = true;
                        }
                    }
                    if (!found) {
                        var b = nextBranch(current);
                        this.branches.push(b);
                        current = b;
                    }
                }
                this.grow = function () {
                    for (i = this.leafs.length - 1; i >= 0; i--) {
                        SBRANCH = null, record = max_dist * 2;
                        var leaf = this.leafs[i];
                        for (j = this.branches.length - 1; j >=0; j--) {
                            var branch = this.branches[j];
                            if (dist(leaf, branch.pos) < min_dist) {
                                eraseShape(leaf);
                                this.leafs.splice(i, 1);
                                SBRANCH = null;
                                break;
                            } else if (dist(leaf, branch.pos) < record) {
                                SBRANCH = branch;
                                record = dist(leaf, branch.pos);
                            }
                        }
                        if (SBRANCH != null) {
                            var ndir = {x: leaf.x - SBRANCH.pos.x, y: leaf.y - SBRANCH.pos.y};
                            var h = dist(ndir);
                            ndir.x /= h;
                            ndir.y /= h;
                            SBRANCH.dir.x += ndir.x;
                            SBRANCH.dir.y += ndir.y;
                            SBRANCH.count++;
                        }
                    }
                    for (i = this.branches.length - 1; i >= 0; i--) {
                        var branch = this.branches[i];
                        if (branch.count > 0) {
                            branch.dir.x /= branch.count;
                            branch.dir.y /= branch.count;
                            var nb = nextBranch(branch);
                            this.branches.push(nb);
                        }
                        branch.count = 0;
                        branch.dir = {x: branch.dirc.x, y: branch.dirc.y};
                    }
                }

        }
        var t = new tree();
        animate(function () {
            t.grow();
        })