        canvas2d();
        var r1 = rec({x: 0, y: 0, w: 15, h: 15});
        var r2 = rec({x: 35, y: 35, w: 15, h: 15});
        update(function () {
            clear();
            save();
            translate(WIDTH / 2, HEIGHT / 2);
            r1.draw();
            r2.x = MP_X-TRANS_STAT[0];
            r2.y = MP_Y-TRANS_STAT[1];
            rotate(-PI / 4);
            r2.draw();
            restore();

            if (intersect(r1, r2)) {
                r2.color = "red";
            } else {
                r2.color = "white";
            }
        });
    