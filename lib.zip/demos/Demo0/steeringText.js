var r = 1, b = 1, g = 1;
var c = canvas2d(1076,600,600,600);
background(COLORS.BLACK);
var arcs = [];
var words = ["Hello World", "today,", "we Are", "Going", "to introduce", "A New", "Javascript", "Library", "Known As", "PxShader.JS"];
var wi = 0;
function updatep(txt) {
    arcs = [];
    var hello = text({x: 15, y: 300, txt: txt, font: "200px impact"});
    pt = toPoints(hello, 9);
    pt.forEach((p) => {
        arcs.push(arc({x: rand(0, WIDTH), y: rand(0, HEIGHT), r: 5, v: {x: 0, y: 0}, t: {x: p.x, y: p.y}, f: {x: 0, y: 0}}));
    });
}
update(function () {
    var bool = true;
    clear();
    arcs.forEach((c, i) => {
        //away from mouse position
        if (abs(MP_X - c.x) < 100 && abs(MP_Y - c.y) < 100) {
            c.f.x = ((MP_X - c.x) / 10);
            c.f.y = ((MP_Y - c.y) / 10);
        } else {
            c.f.x = 0;
            c.f.y = 0;
        }
        //to target position  
        var dif = {x: c.t.x - c.x, y: c.t.y - c.y};
        if (abs(dif.x) < 100 && abs(dif.y) < 100) {
            c.v.x = dif.x / 100 * 7;
            c.v.y = dif.y / 100 * 7;
        } else {
            c.v.x = (dif.x / WIDTH) * 10;
            c.v.y = (dif.y / HEIGHT) * 10;
        }
        c.x += c.v.x;
        c.y += c.v.y;
        c.x -= c.f.x;
        c.y -= c.f.y;
        if (c.color === "white") {
            r += 15;
            if (r >= 255) {
                r = 0
                g += 15;
            } else if (g >= 255) {
                g = 0;
                b += 15;
            }
            if (b > 255) {
                b = 0;
            }
            c.color = `rgb(${r},${g},${b})`;
        }
        c.draw();
        if (c.v.x < 0.00001 && c.v.y < 0.01) {
            bool = bool && true;
        } else {
            bool = bool && false;
        }
    })
    if (wi === words.length) {
        bool = false;
    }
    if (bool) {
        updatep(words[wi]);
        wi++;
    }
}, 60);