canvas2d(1520,600);
        var moon = arc({x:70,y:70,r:40,color:COLORS.BEIGE});
        background(COLORS.GRAY);
        var c1 = arc({x: 35, y: HEIGHT - 15, r: 15,color:COLORS.WHITE,stroke:{color:COLORS.BLACK,width:10,coop:true}});
        var r1 = rec({x: 10, y: HEIGHT - 60, w: 200, h: 40,color:COLORS.LIGHTCORAL});
        var r2 = rec({x: 75, y: HEIGHT - 90, w: 60, h: 30,color:COLORS.LIGHTBLUE,stroke:{color:COLORS.LIGHTCORAL,width:7,coop:true}});
        var c2 = arc({x: r1.x + r1.w - 35, y: HEIGHT - 15, r: 15,color:COLORS.WHITE,stroke:{color:COLORS.BLACK,width:10,coop:true}});
        var carA = objArray([r1, r2, c1, c2]);
        
         c1 = arc({x: WIDTH-175, y: HEIGHT - 15, r: 15,color:COLORS.WHITE,stroke:{color:COLORS.BLACK,width:10,coop:true}});
         r1 = rec({x: WIDTH-215, y: HEIGHT - 60, w: 200, h: 40,color:COLORS.LIGHTGREEN});
         r2 = rec({x: WIDTH-155, y: HEIGHT - 90, w: 60, h: 30,color:COLORS.LIGHTBLUE,stroke:{color:COLORS.LIGHTGREEN,width:7,coop:true}});
         c2 = arc({x: r1.x + r1.w - 35, y: HEIGHT - 15, r: 15,color:COLORS.WHITE,stroke:{color:COLORS.BLACK,width:10,coop:true}});
        var  carB = objArray([r1, r2, c1, c2]);
        var vx = 0;
        var ax = 0;
        animate(function () {
            carA.x += vx;
            carB.x -= vx/2;
            vx+=ax;
            ax+=0.00001;
            if(intersect(carA,carB)){
                vx=0;
                ax=0;
            }
        });