
        canvas2d();
        var c = arc({x: WIDTH / 3 + 20, y: 20, r: 10});
        var l1 = line({from: [WIDTH / 3, 100], to: [WIDTH / 2, 200]}),
        l2 = line({from: [WIDTH / 4, HEIGHT / 2 + 100], to: [WIDTH / 2 + 30, HEIGHT / 2]});
        l3 = line({from: [WIDTH / 5, 2 * HEIGHT / 3], to: [WIDTH / 2 + 30, HEIGHT]});
        animate(function () {
            clear();

            if (intersect(c, l1)) {
                c.x += l1.grad;
            } else if (intersect(c, l2)) {
                c.x += l2.grad;
            } else if (intersect(c, l3)) {
                    c.x += l3.grad;
            } else {
                c.color = COLORS.ALICEBLUE;
                c.y += 3;
            }
        })