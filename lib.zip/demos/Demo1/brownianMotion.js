canvas2d(400, 400);
background(COLORS.BLACK);
particle = arc({x: WIDTH / 2, y: HEIGHT / 2, r: 2});
function dir() {
    guess = rand(1, 3);
    dx = rand(1, 2) === 1 ? 1 : -1;
    dy = rand(1, 2) === 1 ? 1 : -1;
    particle.x += dx * guess;
    particle.y += dy * guess;
}
animate(dir);