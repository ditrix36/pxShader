var c = canvas2d(1590,750,true,true),
        fires = [];
        var sky = img({src:"assets/Ultra_Voilet.jpg",x:0,y:0,w:WIDTH,h:HEIGHT});
function createFire(x, y, color, m) {
    if (y !== undefined && x !== undefined) {
        var obj = {
            x: 2 * cos(m) + x,
            y: 2 * sin(m) + y,
            r: 2,
            color: color,
            a: -1,
            v: {
                x: 3 * cos(m),
                y: 3 * sin(m)
            },
            lifespan: rand(5, 40),
            o: {
                x: x,
                y: y
            }
        }
    } else {
        var obj = {
            x: rand(10, WIDTH - 10),
            y: HEIGHT,
            r: 4,
            color: rand(0, COLORS.length),
            a: -1,
            v: rand(0, 50)
        }
    }
    return obj;
}
function anim() {
    var fw = createFire();
    if ((fw.v < 35) && (fw.v > 30) && fires.length < 100) {
        fires.push(arc(fw));
    }
    fires.forEach((f, i) => {
        if (typeof(f.lifespan)==="number") {
            if (f.lifespan > 0) {
                var alpha = Math.ceil((f.lifespan / 30) * 255);
                alpha = alpha.toString(16);
                f.lifespan--;
                if (f.color.length > 8) {
                    f.color = f.color.substr(0, 7);
                }
                f.color += alpha;
            } else {
                eraseShape(f);
                fires.splice(i, 1);
                return;
            }
        }
        if (typeof (f.v) === "object") {
            f.draw();
            f.x += f.v.x;
            f.y += f.v.y;
        } else {
            f.v += f.a;
            f.y -= f.v;
        }
        if (f.y < 0 || f.y > HEIGHT) {
            eraseShape(f),
            fires.splice(i, 1);
            return;
        }
        if (f.v <= 0 && f.lifespan === undefined) {
            for (m = 0; m < 2 * PI; m += 0.1) {
                fires.push(arc(createFire(f.x, f.y, f.color, m)));
            }
            eraseShape(f);
            fires.splice(i, 1);
            return;
        }
    })
}
animate(anim);