canvas2d(800, 600);
var g = 20;//gravity
var i = 0;
var visuals = [];
var pRec = rec({x: 0, y: 100, w: 32, h: 64, color: COLORS.RED});
var boxes = [];
var gRec = rec({x: 0, y: 0, w: WIDTH, h: HEIGHT, color: COLORS.SKYBLUE});
var yug = img({x: 0, y: HEIGHT / 2, src: "assets/ninja_full.png", w: 32, h: 64});
var score = text({x: WIDTH / 5, y: 50, txt: "SCORE:0", value: 0});
yug.mode = 1;
yug.start = 1;
for (y = 0; y < 5; y++) {
    for (x = 0; x < 10; x++) {
        yug.map(x + "" + y, [x * 32, y * 64], 38, 65, WIDTH / HEIGHT);
    }
}
function Lose() {
    text({x:WIDTH/2,y:HEIGHT/2,txt:"YOU LOSE"}).draw(); 
    stopAnim();
}
yug.start = 17;
yug.mode = 2;
yug.limit = 19;
animate(function () {
    //gravity
    eraseShape(score);
    score = text(score);
    if (visuals.length > 1) {
        visuals.forEach((v) => {
            clear();
            if (intersect(v, pRec)) {
                Lose();
                return;
            }
            eraseShape(v);
        });
        visuals.length = 0;
    }
    pRec.x = yug.x;
    pRec.y = yug.y;
    if (yug.y < HEIGHT) {
        yug.y += g;
    }
    i += 0.1;
    if (i >= g / 4) {
        boxes.push(rec({x: WIDTH, y: rand(100, HEIGHT - 300), h: rand(140, 200), w: rand(40, 60), color: COLORS.SKYBLUE + "00"}));
        i = 0;
    }
    boxes.forEach((b, i) => {
        b.x -= 5;
        visuals.push(rec({x: b.x, y: 0, h: b.y, w: b.w, color: COLORS.CRIMSON, stroke: {coop: true}})),
        visuals.push(rec({x: b.x, y: b.y + b.h, h: HEIGHT - (b.y + b.h), w: b.w, color: COLORS.CRIMSON, stroke: {coop: true}}));
        visuals[0].draw();
        visuals[1].draw();
        if (intersect(b, pRec)) {
            score.txt = "SCORE: " + score.value++;
        }
        if (!intersect(b, gRec)) {
            eraseShape(b);
            boxes.splice(i, 1);
        }
    })
    if (boxes.length >= 1 && yug.y >= HEIGHT - 10) {
        Lose();
    }
    if (KEY_P === "ArrowUp" || KEY_P === "w") {
        yug.y -= (yug.index % 2) * 64;
    }
    score.draw();
}, 10);